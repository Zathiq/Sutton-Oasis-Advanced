# Sutton Oasis Technical Services LLC: Website

A fast, static, single-page website for Sutton Oasis Technical Services LLC, Dubai. It has no build step, no framework and no external JavaScript.

## What's in the folder

```
index.html              The page (all sections, SEO metadata, structured data)
assets/css/styles.css   All styles (responsive, accessible focus states, reduced-motion support)
assets/js/boot.js       Tiny head script that switches on motion styles before first paint
assets/js/main.js       Mobile menu, active-section highlighting, copy buttons, thermal image lens, form validation and sending
assets/js/fx.js         Motion layer: reticle cursor, hero airflow field, scroll reveals, parallax, ticker, magnetic buttons
assets/img/             Logo variants, favicons, social share image and section photography
robots.txt, sitemap.xml Search engine files
_headers                Security headers for Netlify / Cloudflare Pages
vercel.json             Security headers for Vercel
.htaccess               HTTPS redirect, security headers and caching for Apache / cPanel hosting
```

## 1. Preview locally

Open `index.html` in a browser, or run a local server from this folder:

```bash
python3 -m http.server 8080
# then visit http://localhost:8080
```

## 2. Connect the enquiry form (required before launch)

Out of the box, the form validates every field and then prepares an email to **info@suttonoasis.com** in the visitor's email app (with a "copy enquiry" fallback). To have enquiries sent straight to the inbox without the visitor's email app, connect a form service:

1. Create a free form at [Formspree](https://formspree.io) using info@suttonoasis.com as the recipient.
2. Copy the form endpoint, e.g. `https://formspree.io/f/abcdwxyz`.
3. In `index.html`, find `<form class="form" id="enquiry-form" ... data-endpoint="">` and paste the endpoint:
   `data-endpoint="https://formspree.io/f/abcdwxyz"`
4. Submit a test enquiry and confirm it arrives.

The script sends JSON (`name, company, email, phone, service, message`) and only shows "sent" when the service confirms receipt. A hidden spam-trap field blocks simple bots. If you use a different provider, add its domain to `connect-src` in `_headers`, `vercel.json` or `.htaccess`.

## 3. Deploy

Any static host works. Pick one:

**Netlify / Cloudflare Pages:** drag and drop this folder into a new site (or connect a Git repo with no build command and `/` as the output folder). `_headers` is applied automatically.

**Vercel:** `npx vercel --prod` from this folder, or import the repo with framework preset "Other". `vercel.json` is applied automatically.

**cPanel / Apache hosting (common with UAE hosting providers):** upload the contents of this folder (including the hidden `.htaccess` file) to `public_html/` using File Manager or FTP.

Then point the domain:
- Add the custom domain `suttonoasis.com` and `www.suttonoasis.com` in your host's dashboard and follow its DNS instructions (an `A` record for the root and a `CNAME` for `www`).
- Make sure HTTPS is enabled (all three hosts above issue free certificates).

> Keep the existing MX records for info@suttonoasis.com unchanged when editing DNS, or email will stop working.

## 4. After going live

- If the final domain is not `https://www.suttonoasis.com/`, update it in `index.html` (canonical link, `og:url`, `og:image`, and the JSON-LD block), `robots.txt` and `sitemap.xml`.
- Submit `sitemap.xml` in [Google Search Console](https://search.google.com/search-console).
- Create or claim the **Google Business Profile** for the company so it appears in Maps and local search.

## Editing content

- **Text:** all copy is in `index.html`, grouped by section (`#home`, `#about`, `#services`, `#why-us`, `#industries`, `#contact`, footer).
- **Contact details** appear in the header, hero, contact section, footer, JSON-LD block and `assets/js/main.js` (`CONTACT_EMAIL`). Search for `+971` and `info@` to update every instance.
- **Images:** replace files in `assets/img/` with the same names, or update the `src`, `width` and `height` attributes. Keep photos around 1000 px wide and under 200 KB (JPEG quality 75 to 80).
- **Colours and fonts** are defined once at the top of `assets/css/styles.css`.

## Notes on content

- The site makes no claims about certifications, accreditations, clients or past projects. Add these only when they are verified and you have permission to publish them.
- Section photography is AI-generated and illustrative. Replacing it with photos of your own team and equipment on site will make the site even more credible.
- The "Air balancing record" in *Why choose us* is labelled as an illustrative format. Swap in a real (anonymised) report extract if you prefer.
- The thermal image in *Thermographic Survey* is an illustrative infrared rendering.

## Motion and interaction

- **Reticle cursor** on desktop mice: an engineering crosshair that grows over links, shows labels such as *View* and *Call*, and reads out X/Y coordinates over the hero. Touch devices keep their normal behaviour.
- **Hero airflow field:** live streamlines drawn on a canvas that bend around the pointer; a click sends out a pressure pulse. It pauses when the hero is off screen.
- **Scroll choreography:** headings rise word by word, images open with an inspection scan line, photos have gentle parallax, the service ticker reacts to scroll speed and direction, and a progress gauge runs under the header and around the back-to-top button.
- **Data in motion:** the sample report rows stagger in, measured values count up and the deviation bars draw out; the duct test manometer fills and holds.
- **Accessibility:** everything respects the visitor's *reduce motion* setting, and the page is complete and readable without JavaScript.

To tone motion down, remove `assets/js/fx.js` (and its script tag); the site keeps working as a static page.

## Technical checklist (done)

- Responsive from 320 px phones to wide desktops, with no horizontal scrolling
- Semantic headings (one `h1`), skip link, labelled form fields, inline error messages, visible keyboard focus, reduced-motion support
- Meta description, Open Graph and Twitter cards, canonical URL, `ProfessionalService` structured data, sitemap and robots file
- Click-to-call (`tel:`) and email (`mailto:`) links, plus copy buttons
- Security headers: Content-Security-Policy with no inline scripts, HSTS, nosniff, frame and referrer protection
- Lazy-loaded images with fixed dimensions (no layout shift); total page weight around 1 MB
