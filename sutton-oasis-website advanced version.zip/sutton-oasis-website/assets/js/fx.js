/* Sutton Oasis: motion layer (reveals, reticle cursor, airflow field, parallax, ticker).
   Progressive enhancement only: the page is complete without this file. */
(function () {
  'use strict';

  var root = document.documentElement;
  var FX = root.classList.contains('fx');
  var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var fine = window.matchMedia('(hover: hover) and (pointer: fine)').matches;
  var $ = function (s, c) { return (c || document).querySelector(s); };
  var $$ = function (s, c) { return Array.prototype.slice.call((c || document).querySelectorAll(s)); };
  var lerp = function (a, b, t) { return a + (b - a) * t; };
  var clamp = function (v, a, b) { return Math.min(Math.max(v, a), b); };
  var easeOut = function (t) { return 1 - Math.pow(1 - t, 3); };

  /* ---------- Dubai clock ---------- */
  var clocks = $$('[data-clock]');
  if (clocks.length) {
    var fmt;
    try { fmt = new Intl.DateTimeFormat('en-GB', { timeZone: 'Asia/Dubai', hour: '2-digit', minute: '2-digit', hour12: false }); } catch (e) { fmt = null; }
    var tickClock = function () {
      if (!fmt) return;
      var t = fmt.format(new Date()) + ' GST';
      clocks.forEach(function (el) { el.textContent = t; });
    };
    tickClock();
    setInterval(tickClock, 15000);
  }

  /* ---------- Deviation bars in the report sheet (static, always) ---------- */
  $$('.sheet td[data-dev]').forEach(function (td) {
    var d = parseFloat(td.getAttribute('data-dev'));
    if (isNaN(d)) return;
    var bar = document.createElement('span');
    bar.className = 'devbar' + (d < 0 ? ' neg' : '') + (Math.abs(d) > 10 ? ' out' : '');
    bar.setAttribute('aria-hidden', 'true');
    var b = document.createElement('b');
    b.style.width = (Math.min(Math.abs(d) / 20, 1) * 50).toFixed(1) + '%';
    bar.appendChild(b);
    td.insertBefore(bar, td.firstChild);
  });

  /* ---------- Scroll progress + back-to-top ring (always) ---------- */
  var progress = $('.scroll-progress');
  var toTop = $('.to-top');
  var ttFill = toTop && $('.tt-fill', toTop);
  var hero = $('.hero');

  /* ================================================================
     Everything below is motion. Stop here for reduced motion.
     ================================================================ */
  var state = { sy: window.scrollY, lastSy: window.scrollY, vel: 0, vh: window.innerHeight, scrolled: true };
  window.addEventListener('scroll', function () { state.sy = window.scrollY; state.scrolled = true; }, { passive: true });
  window.addEventListener('resize', function () { state.vh = window.innerHeight; state.scrolled = true; });

  function updateScrollUI() {
    var max = Math.max(1, document.documentElement.scrollHeight - state.vh);
    var p = clamp(state.sy / max, 0, 1);
    if (progress) progress.style.transform = 'scaleX(' + p.toFixed(4) + ')';
    if (ttFill) ttFill.style.strokeDashoffset = (100 - p * 100).toFixed(2);
    if (toTop) toTop.classList.toggle('show', state.sy > state.vh * 0.9);
  }

  if (reduce || !FX) {
    updateScrollUI();
    window.addEventListener('scroll', updateScrollUI, { passive: true });
    window.addEventListener('resize', updateScrollUI);
    return;
  }

  /* ---------- Reveal system ---------- */
  // Clipped elements report no intersection, so image frames are watched through their parent.
  var proxies = new Map();
  var io = new IntersectionObserver(function (entries) {
    entries.forEach(function (e) {
      if (!e.isIntersecting) return;
      var targets = proxies.get(e.target) || [e.target];
      targets.forEach(function (t) {
        t.classList.add('in');
        if (typeof t._onIn === 'function') t._onIn();
      });
      io.unobserve(e.target);
    });
  }, { rootMargin: '0px 0px -10% 0px', threshold: 0.1 });

  function reveal(el, cls, delay) {
    if (!el) return;
    el.classList.add(cls || 'r');
    if (delay) el.style.setProperty('--d', delay + 'ms');
    if (cls === 'r-img' && el.parentElement) {
      var host = el.parentElement;
      if (!proxies.has(host)) proxies.set(host, []);
      proxies.get(host).push(el);
      io.observe(host);
    } else {
      io.observe(el);
    }
  }

  function split(el) {
    if (!el || el.classList.contains('split')) return;
    var i = 0;
    (function walk(node) {
      Array.prototype.slice.call(node.childNodes).forEach(function (ch) {
        if (ch.nodeType === 3) {
          var parts = ch.textContent.split(/(\s+)/);
          var frag = document.createDocumentFragment();
          parts.forEach(function (p) {
            if (!p) return;
            if (/^\s+$/.test(p)) { frag.appendChild(document.createTextNode(' ')); return; }
            var w = document.createElement('span');
            w.className = 'w';
            var inner = document.createElement('span');
            inner.textContent = p;
            inner.style.setProperty('--i', i++);
            w.appendChild(inner);
            frag.appendChild(w);
          });
          node.replaceChild(frag, ch);
        } else if (ch.nodeType === 1 && ch.namespaceURI !== 'http://www.w3.org/2000/svg') {
          walk(ch);
        }
      });
    })(el);
    el.classList.add('split');
  }

  // Hero headline: plays on load
  var heroTitle = $('#hero-title');
  if (heroTitle) {
    split(heroTitle);
    heroTitle.style.setProperty('--d', '120ms');
    requestAnimationFrame(function () { requestAnimationFrame(function () { heroTitle.classList.add('in'); }); });
  }

  // Section heads
  $$('.section-head').forEach(function (head) {
    Array.prototype.slice.call(head.children).forEach(function (ch, i) {
      if (/^H[23]$/.test(ch.tagName)) { split(ch); reveal(ch, 'split-target', 80); ch.classList.remove('split-target'); }
      else reveal(ch, 'r', i * 110);
    });
  });
  // Headings outside section heads
  $$('.about-copy h2, .service-body h3, .contact-card h3, .form h3').forEach(function (h) { split(h); io.observe(h); });

  $$('.about-copy > .eyebrow, .about-copy > p').forEach(function (el, i) { reveal(el, 'r', i * 90); });
  $$('.values .value').forEach(function (el, i) { reveal(el, 'r', 120 + i * 80); });
  $$('.service-body').forEach(function (body) {
    Array.prototype.slice.call(body.children).forEach(function (ch, i) {
      if (ch.tagName !== 'H3') reveal(ch, 'r', i * 80);
    });
  });
  $$('.strip-item').forEach(function (el, i) { reveal(el, 'r', 500 + i * 70); });
  $$('.reasons .reason').forEach(function (el, i) { reveal(el, 'r', i * 80); });
  $$('.industry').forEach(function (el, i) { reveal(el, 'r', i * 90); });
  reveal($('.audience'), 'r', 100);
  reveal($('.contact-card'), 'r', 0);
  reveal($('.form'), 'r', 140);
  $$('.footer-grid > *').forEach(function (el, i) { reveal(el, 'r', i * 80); });

  // Image frames: wipe + scan line, plus parallax
  var parallax = [];
  $$('.service-media').forEach(function (m) {
    var img = m.querySelector(':scope > img');
    if (img) {
      m.classList.add('px-frame');
      reveal(m, 'r-img');
      parallax.push({ frame: m, img: img });
    } else {
      reveal(m.firstElementChild, 'r-img');
    }
  });
  var about = $('.about-media');
  if (about) {
    about.classList.add('px-frame');
    reveal(about, 'r-img');
    parallax.push({ frame: about, img: about.querySelector('img') });
  }

  // Report sheet: rows stagger, measured values count up
  var sheet = $('.sheet');
  if (sheet) {
    $$('tbody tr', sheet).forEach(function (tr, i) {
      var d = 250 + i * 90;
      tr.style.setProperty('--d', d + 'ms');
      var b = tr.querySelector('.devbar b');
      if (b) b.style.setProperty('--d', (d + 250) + 'ms');
    });
    sheet._onIn = function () {
      $$('td[data-count]', sheet).forEach(function (td, i) {
        var end = parseFloat(td.getAttribute('data-count'));
        var start = performance.now() + 250 + i * 90;
        td.textContent = '0';
        (function step(now) {
          var t = clamp((now - start) / 1100, 0, 1);
          td.textContent = String(Math.round(end * easeOut(t)));
          if (t < 1) requestAnimationFrame(step);
        })(performance.now());
      });
    };
    io.observe(sheet);
  }

  // Readouts: instrument-style decode on load
  var glyphs = '0123456789ΩΔ°/#%+';
  $$('.readout b').forEach(function (b, i) {
    var final = b.textContent;
    var t0 = performance.now() + 700 + i * 120;
    (function step(now) {
      var t = (now - t0) / 650;
      if (t >= 1) { b.textContent = final; return; }
      if (t > 0) {
        var out = '';
        for (var k = 0; k < final.length; k++) out += (k / final.length < t) ? final[k] : glyphs[(Math.random() * glyphs.length) | 0];
        b.textContent = out;
      }
      requestAnimationFrame(step);
    })(performance.now());
  });

  root.classList.add('fx-ready');

  /* ---------- Spotlight surfaces ---------- */
  var spots = $$('.strip-item, .industry, .value, .subtest, .reason');
  spots.forEach(function (el) {
    el.classList.add('spot');
    el.addEventListener('pointermove', function (e) {
      var r = el.getBoundingClientRect();
      el.style.setProperty('--mx', (e.clientX - r.left) + 'px');
      el.style.setProperty('--my', (e.clientY - r.top) + 'px');
    });
  });

  /* ---------- Magnetic buttons + tilt (fine pointers) ---------- */
  if (fine) {
    $$('[data-magnetic]').forEach(function (el) {
      el.addEventListener('pointermove', function (e) {
        var r = el.getBoundingClientRect();
        var dx = (e.clientX - (r.left + r.width / 2)) * 0.22;
        var dy = (e.clientY - (r.top + r.height / 2)) * 0.32;
        el.style.transform = 'translate(' + dx.toFixed(1) + 'px,' + dy.toFixed(1) + 'px)';
      });
      el.addEventListener('pointerleave', function () { el.style.transform = ''; });
    });
    if (sheet) {
      sheet.addEventListener('pointermove', function (e) {
        var r = sheet.getBoundingClientRect();
        var px = (e.clientX - r.left) / r.width - 0.5;
        var py = (e.clientY - r.top) / r.height - 0.5;
        sheet.style.transform = 'rotateX(' + (-py * 5).toFixed(2) + 'deg) rotateY(' + (px * 7).toFixed(2) + 'deg)';
      });
      sheet.addEventListener('pointerleave', function () { sheet.style.transform = ''; });
    }
  }

  /* ---------- Reticle cursor ---------- */
  var cursor = null, cDot, cRing, cLabel, cCoords;
  var mouse = { x: -100, y: -100, rx: -100, ry: -100, seen: false };
  if (fine) {
    cursor = document.createElement('div');
    cursor.className = 'cursor is-out';
    cursor.setAttribute('aria-hidden', 'true');
    cursor.innerHTML = '<div class="cursor-ring"><i class="cr-shape"></i><span class="cursor-label"></span></div><div class="cursor-dot"></div><div class="cursor-coords"></div>';
    document.body.appendChild(cursor);
    cDot = $('.cursor-dot', cursor);
    cRing = $('.cursor-ring', cursor);
    cLabel = $('.cursor-label', cursor);
    cCoords = $('.cursor-coords', cursor);
    root.classList.add('has-cursor');

    var pad = function (n) { n = Math.max(0, Math.round(n)); return ('0000' + n).slice(-4); };

    window.addEventListener('pointermove', function (e) {
      if (e.pointerType && e.pointerType !== 'mouse') return;
      mouse.x = e.clientX; mouse.y = e.clientY;
      if (!mouse.seen) { mouse.rx = mouse.x; mouse.ry = mouse.y; mouse.seen = true; }
      cursor.classList.remove('is-out');
      cDot.style.transform = 'translate3d(' + mouse.x + 'px,' + mouse.y + 'px,0)';
      if (cursor.classList.contains('show-coords') && hero) {
        var hr = hero.getBoundingClientRect();
        cCoords.textContent = 'X ' + pad(mouse.x - hr.left) + '\nY ' + pad(mouse.y - hr.top);
      }
    }, { passive: true });

    document.addEventListener('pointerover', function (e) {
      var t = e.target;
      if (!(t instanceof Element)) return;
      var hide = t.closest('input, textarea, select, [data-cursor-hide]');
      var link = t.closest('a, button, label[for], [data-cursor], .copy-btn');
      var label = link ? (link.getAttribute('data-cursor') || '') : '';
      var dark = t.closest('.hero, .why, .site-footer, .contact-card, .diagram, .to-top');
      cursor.classList.toggle('is-hidden', !!hide);
      cursor.classList.toggle('is-link', !!link && !label);
      cursor.classList.toggle('has-label', !!label);
      cursor.classList.toggle('on-dark', !!dark);
      cursor.classList.toggle('show-coords', !!t.closest('.hero') && !link);
      if (label) cLabel.textContent = label;
    });
    document.addEventListener('pointerdown', function () { cursor.classList.add('is-down'); });
    document.addEventListener('pointerup', function () { cursor.classList.remove('is-down'); });
    document.documentElement.addEventListener('mouseleave', function () { cursor.classList.add('is-out'); });
  }

  /* ---------- Hero airflow field ---------- */
  var flow = null;
  var canvas = $('.hero-flow');
  if (canvas && hero && canvas.getContext) {
    var ctx = canvas.getContext('2d');
    flow = { w: 0, h: 0, dpr: Math.min(window.devicePixelRatio || 1, 1.5), parts: [], t: 0, visible: true,
             mx: -9999, my: -9999, pulse: null };
    var spawn = function (p, anywhere) {
      p.x = anywhere ? Math.random() * flow.w : -10 - Math.random() * 60;
      p.y = Math.random() * flow.h;
      p.age = 0;
      p.life = 140 + Math.random() * 220;
      return p;
    };
    var size = function () {
      var r = hero.getBoundingClientRect();
      flow.w = r.width; flow.h = r.height;
      canvas.width = Math.round(flow.w * flow.dpr);
      canvas.height = Math.round(flow.h * flow.dpr);
      ctx.setTransform(flow.dpr, 0, 0, flow.dpr, 0, 0);
      var target = Math.round(clamp(flow.w * flow.h / 1500, 180, 900));
      while (flow.parts.length < target) flow.parts.push(spawn({}, true));
      flow.parts.length = target;
    };
    size();
    if ('ResizeObserver' in window) new ResizeObserver(size).observe(hero);
    else window.addEventListener('resize', size);

    new IntersectionObserver(function (en) { flow.visible = en[0].isIntersecting; }).observe(hero);

    hero.addEventListener('pointermove', function (e) {
      var r = canvas.getBoundingClientRect();
      flow.mx = e.clientX - r.left; flow.my = e.clientY - r.top;
    });
    hero.addEventListener('pointerleave', function () { flow.mx = flow.my = -9999; });
    hero.addEventListener('pointerdown', function (e) {
      var r = canvas.getBoundingClientRect();
      flow.pulse = { x: e.clientX - r.left, y: e.clientY - r.top, s: 1 };
    });
    setTimeout(function () { canvas.classList.add('on'); }, 350);
    flow.step = function () {
      var w = flow.w, h = flow.h, t = (flow.t += 0.006);
      ctx.globalCompositeOperation = 'destination-out';
      ctx.fillStyle = 'rgba(0,0,0,0.085)';
      ctx.fillRect(0, 0, w, h);
      ctx.globalCompositeOperation = 'source-over';
      ctx.lineWidth = 1;
      ctx.strokeStyle = w < 700 ? 'rgba(43,184,203,0.38)' : 'rgba(43,184,203,0.55)';
      ctx.beginPath();
      var R = 130, R2 = R * R, pu = flow.pulse;
      for (var i = 0; i < flow.parts.length; i++) {
        var p = flow.parts[i];
        var a = Math.sin(p.x * 0.0031 + t) * 0.85 + Math.cos(p.y * 0.0047 - t * 0.8) * 0.65 + Math.sin((p.x + p.y) * 0.0019 + t * 0.5) * 0.45;
        var vx = 1.25 + Math.cos(a * 0.9) * 0.9;
        var vy = Math.sin(a * 0.9) * 1.1;
        var dx = p.x - flow.mx, dy = p.y - flow.my, d2 = dx * dx + dy * dy;
        if (d2 < R2) {
          var d = Math.sqrt(d2) || 1, f = (1 - d / R) * 3.2;
          vx += dx / d * f; vy += dy / d * f;
        }
        if (pu) {
          var px = p.x - pu.x, py = p.y - pu.y, pd = Math.sqrt(px * px + py * py) || 1;
          var ring = Math.abs(pd - (1 - pu.s) * 420);
          if (ring < 60) { var pf = (1 - ring / 60) * 6 * pu.s; vx += px / pd * pf; vy += py / pd * pf; }
        }
        var nx = p.x + vx, ny = p.y + vy;
        ctx.moveTo(p.x, p.y);
        ctx.lineTo(nx, ny);
        p.x = nx; p.y = ny; p.age++;
        if (p.x > w + 10 || p.y < -10 || p.y > h + 10 || p.age > p.life) spawn(p, Math.random() < 0.35);
      }
      ctx.stroke();
      if (pu) { pu.s -= 0.018; if (pu.s <= 0) flow.pulse = null; }
    };
  }

  /* ---------- Ticker ---------- */
  var ticker = $('.ticker'), track = ticker && $('.ticker-track', ticker);
  var tk = { x: 0, visible: false, dir: 1 };
  if (ticker) new IntersectionObserver(function (en) { tk.visible = en[0].isIntersecting; }).observe(ticker);

  /* ---------- Hero image parallax ---------- */
  var heroImg = $('.hero-media img');
  var hp = { x: 0, y: 0, tx: 0, ty: 0 };
  if (hero && heroImg && fine) {
    hero.addEventListener('pointermove', function (e) {
      var r = hero.getBoundingClientRect();
      hp.tx = ((e.clientX - r.left) / r.width - 0.5) * -16;
      hp.ty = ((e.clientY - r.top) / r.height - 0.5) * -12;
    });
    hero.addEventListener('pointerleave', function () { hp.tx = hp.ty = 0; });
  }
  if (heroImg) heroImg.style.scale = '1.06';

  /* ---------- Main loop ---------- */
  function frame() {
    // scroll velocity
    var dv = state.sy - state.lastSy;
    state.lastSy = state.sy;
    state.vel = lerp(state.vel, dv, 0.12);

    if (state.scrolled) {
      updateScrollUI();
      parallax.forEach(function (o) {
        var r = o.frame.getBoundingClientRect();
        if (r.bottom < -50 || r.top > state.vh + 50) return;
        var p = (r.top + r.height / 2 - state.vh / 2) / (state.vh / 2 + r.height / 2);
        o.img.style.translate = '0 ' + (p * r.height * 0.05).toFixed(1) + 'px';
      });
      state.scrolled = false;
    }

    if (heroImg && state.sy < state.vh * 1.2) {
      hp.x = lerp(hp.x, hp.tx, 0.06);
      hp.y = lerp(hp.y, hp.ty, 0.06);
      heroImg.style.translate = hp.x.toFixed(2) + 'px ' + (hp.y + state.sy * 0.12).toFixed(2) + 'px';
    }

    if (cursor && mouse.seen) {
      mouse.rx = lerp(mouse.rx, mouse.x, 0.2);
      mouse.ry = lerp(mouse.ry, mouse.y, 0.2);
      var tr = 'translate3d(' + mouse.rx.toFixed(1) + 'px,' + mouse.ry.toFixed(1) + 'px,0)';
      cRing.style.transform = tr;
      cCoords.style.transform = tr;
    }

    if (flow && flow.visible && !document.hidden) flow.step();

    if (track && tk.visible) {
      if (Math.abs(state.vel) > 0.5) tk.dir = state.vel > 0 ? 1 : -1;
      tk.x -= (0.55 + Math.min(Math.abs(state.vel) * 0.25, 14)) * tk.dir;
      var half = track.scrollWidth / 2;
      if (tk.x <= -half) tk.x += half;
      if (tk.x > 0) tk.x -= half;
      track.style.transform = 'translate3d(' + tk.x.toFixed(1) + 'px,0,0)';
    }

    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);
})();
