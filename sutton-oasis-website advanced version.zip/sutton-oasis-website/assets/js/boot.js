/* Enables motion styles before first paint when the visitor allows motion */
(function () {
  try {
    if ('IntersectionObserver' in window && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      document.documentElement.classList.add('fx');
    }
  } catch (e) { /* no-op */ }
})();
