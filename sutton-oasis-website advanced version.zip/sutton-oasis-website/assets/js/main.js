/* Sutton Oasis Technical Services LLC: site behaviour (no dependencies) */
(function () {
  'use strict';

  var CONTACT_EMAIL = 'info@suttonoasis.com';

  /* ---------- Year ---------- */
  document.querySelectorAll('[data-year]').forEach(function (el) {
    el.textContent = String(new Date().getFullYear());
  });

  /* ---------- Header shadow ---------- */
  var header = document.querySelector('.site-header');
  function onScroll() {
    if (header) header.classList.toggle('is-scrolled', window.scrollY > 8);
  }
  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();

  /* ---------- Mobile navigation ---------- */
  var toggle = document.querySelector('.nav-toggle');
  var nav = document.getElementById('site-nav');
  function setNav(open) {
    if (!toggle || !nav) return;
    toggle.setAttribute('aria-expanded', String(open));
    toggle.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
    nav.setAttribute('data-open', String(open));
  }
  if (toggle && nav) {
    toggle.addEventListener('click', function () {
      setNav(toggle.getAttribute('aria-expanded') !== 'true');
    });
    nav.addEventListener('click', function (e) {
      if (e.target.closest('a')) setNav(false);
    });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && toggle.getAttribute('aria-expanded') === 'true') {
        setNav(false);
        toggle.focus();
      }
    });
    document.addEventListener('click', function (e) {
      if (toggle.getAttribute('aria-expanded') === 'true' && !e.target.closest('.site-header')) setNav(false);
    });
    var mq = window.matchMedia('(min-width: 981px)');
    var resetNav = function () { if (mq.matches) setNav(false); };
    if (mq.addEventListener) mq.addEventListener('change', resetNav);
  }

  /* ---------- Current section in nav ---------- */
  var navLinks = Array.prototype.slice.call(document.querySelectorAll('.nav a[href^="#"]'));
  var sections = navLinks
    .map(function (a) { return document.querySelector(a.getAttribute('href')); })
    .filter(Boolean);
  if ('IntersectionObserver' in window && sections.length) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (!entry.isIntersecting) return;
        navLinks.forEach(function (a) {
          if (a.getAttribute('href') === '#' + entry.target.id) a.setAttribute('aria-current', 'true');
          else a.removeAttribute('aria-current');
        });
      });
    }, { rootMargin: '-45% 0px -50% 0px' });
    sections.forEach(function (s) { io.observe(s); });
  }

  /* ---------- Copy buttons ---------- */
  function copyText(text, onDone) {
    var fallback = function () {
      var ta = document.createElement('textarea');
      ta.value = text;
      ta.setAttribute('readonly', '');
      ta.className = 'visually-hidden';
      document.body.appendChild(ta);
      ta.select();
      var ok = false;
      try { ok = document.execCommand('copy'); } catch (err) { ok = false; }
      document.body.removeChild(ta);
      onDone(ok);
    };
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text).then(function () { onDone(true); }, fallback);
        return;
      }
    } catch (err) { /* fall through */ }
    fallback();
  }
  document.addEventListener('click', function (e) {
    var btn = e.target.closest('[data-copy]');
    if (!btn) return;
    var original = btn.getAttribute('data-label') || btn.textContent;
    btn.setAttribute('data-label', original);
    copyText(btn.getAttribute('data-copy'), function (ok) {
      btn.textContent = ok ? 'Copied' : 'Select';
      btn.classList.toggle('is-done', ok);
      window.setTimeout(function () {
        btn.textContent = original;
        btn.classList.remove('is-done');
      }, 1800);
    });
  });

  /* ---------- Thermal lens ---------- */
  document.querySelectorAll('[data-thermal]').forEach(function (box) {
    var btn = box.querySelector('.thermal-toggle');
    var raf = 0;
    var resetTimer = 0;
    function place(clientX, clientY) {
      var r = box.getBoundingClientRect();
      var x = Math.min(Math.max(clientX - r.left, 0), r.width);
      var y = Math.min(Math.max(clientY - r.top, 0), r.height);
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(function () {
        box.style.setProperty('--x', (x / r.width * 100).toFixed(2) + '%');
        box.style.setProperty('--y', (y / r.height * 100).toFixed(2) + '%');
      });
    }
    box.addEventListener('pointerenter', function () {
      clearTimeout(resetTimer);
      box.classList.add('is-tracking');
    });
    box.addEventListener('pointermove', function (e) {
      if (e.target.closest('.thermal-bar')) return;
      place(e.clientX, e.clientY);
    });
    box.addEventListener('pointerleave', function () {
      box.classList.remove('is-tracking');
      resetTimer = window.setTimeout(function () {
        box.style.setProperty('--x', '70%');
        box.style.setProperty('--y', '43%');
      }, 900);
    });
    if (btn) {
      btn.addEventListener('click', function () {
        var full = !box.classList.contains('is-full');
        box.classList.toggle('is-full', full);
        btn.setAttribute('aria-pressed', String(full));
        btn.textContent = full ? 'Show lens view' : 'Show full infrared view';
      });
    }
  });

  /* ---------- Enquiry form ---------- */
  var form = document.getElementById('enquiry-form');
  if (!form) return;
  var statusBox = document.getElementById('form-status');
  var submitBtn = form.querySelector('button[type="submit"]');

  var rules = {
    name: function (v) {
      if (!v) return 'Enter your full name.';
      if (v.length < 2) return 'Name must be at least 2 characters.';
      return '';
    },
    email: function (v) {
      if (!v) return 'Enter your email address.';
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v)) return 'Enter an email address in the format name@company.com.';
      return '';
    },
    phone: function (v) {
      if (!v) return 'Enter a phone number so we can reach you.';
      if (!/^[+()\d\s-]+$/.test(v)) return 'Use digits, spaces and + ( ) - only.';
      var digits = v.replace(/\D/g, '');
      if (digits.length < 7 || digits.length > 15) return 'Enter a phone number of 7 to 15 digits, for example +971 54 130 4006.';
      return '';
    },
    service: function (v) {
      return v ? '' : 'Select the service you need.';
    },
    message: function (v) {
      if (!v) return 'Tell us a little about your project.';
      if (v.length < 10) return 'Add a few more details (at least 10 characters).';
      return '';
    }
  };

  function validateField(name) {
    var input = form.elements[name];
    if (!input || !rules[name]) return true;
    var msg = rules[name](input.value.trim());
    var err = document.getElementById('e-' + name);
    if (msg) {
      input.setAttribute('aria-invalid', 'true');
      if (err) err.textContent = msg;
      return false;
    }
    input.removeAttribute('aria-invalid');
    if (err) err.textContent = '';
    return true;
  }

  Object.keys(rules).forEach(function (name) {
    var input = form.elements[name];
    if (!input) return;
    input.addEventListener('blur', function () {
      if (input.value.trim() || input.getAttribute('aria-invalid')) validateField(name);
    });
    input.addEventListener('input', function () {
      if (input.getAttribute('aria-invalid') === 'true') validateField(name);
    });
    input.addEventListener('change', function () {
      if (input.tagName === 'SELECT') validateField(name);
    });
  });

  function collect() {
    var get = function (n) { return (form.elements[n] && form.elements[n].value || '').trim(); };
    return {
      name: get('name'),
      company: get('company'),
      email: get('email'),
      phone: get('phone'),
      service: get('service'),
      message: get('message')
    };
  }

  function enquiryText(d) {
    return [
      'Name: ' + d.name,
      'Company: ' + (d.company || '-'),
      'Email: ' + d.email,
      'Phone: ' + d.phone,
      'Service required: ' + d.service,
      '',
      d.message
    ].join('\n');
  }

  function el(tag, attrs, text) {
    var node = document.createElement(tag);
    Object.keys(attrs || {}).forEach(function (k) { node.setAttribute(k, attrs[k]); });
    if (text) node.textContent = text;
    return node;
  }

  function showStatus(kind, title, body, actions) {
    statusBox.hidden = false;
    statusBox.className = 'form-status form-status--' + kind;
    statusBox.textContent = '';
    statusBox.appendChild(el('strong', null, title));
    if (body) statusBox.appendChild(el('p', null, body));
    if (actions && actions.length) {
      var row = el('div', { 'class': 'row' });
      actions.forEach(function (a) { row.appendChild(a); });
      statusBox.appendChild(row);
    }
    statusBox.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }

  function showMailDraft(d) {
    var subject = 'Enquiry: ' + d.service + (d.company ? ' (' + d.company + ')' : '');
    var href = 'mailto:' + CONTACT_EMAIL +
      '?subject=' + encodeURIComponent(subject) +
      '&body=' + encodeURIComponent(enquiryText(d));
    var mailBtn = el('a', { 'class': 'btn btn--primary', href: href }, 'Open in email app');
    var copyBtn = el('button', { 'class': 'btn btn--outline', type: 'button' }, 'Copy enquiry text');
    copyBtn.addEventListener('click', function () {
      copyText('To: ' + CONTACT_EMAIL + '\nSubject: ' + subject + '\n\n' + enquiryText(d), function (ok) {
        copyBtn.textContent = ok ? 'Copied' : 'Copy failed';
      });
    });
    showStatus('ok', 'Your enquiry is ready to send',
      'Open it in your email app to send it to ' + CONTACT_EMAIL + '. If your email app does not open, copy the text and email it to us, or call +971 54 130 4006.',
      [mailBtn, copyBtn]);
  }

  form.addEventListener('submit', function (e) {
    e.preventDefault();
    statusBox.hidden = true;

    var firstInvalid = null;
    Object.keys(rules).forEach(function (name) {
      if (!validateField(name) && !firstInvalid) firstInvalid = form.elements[name];
    });
    if (firstInvalid) {
      firstInvalid.focus();
      return;
    }

    // Spam trap: real visitors never fill this hidden field.
    if (form.elements.website && form.elements.website.value) return;

    var data = collect();
    var endpoint = (form.getAttribute('data-endpoint') || '').trim();

    if (!endpoint) {
      showMailDraft(data);
      return;
    }

    submitBtn.disabled = true;
    var label = submitBtn.innerHTML;
    submitBtn.textContent = 'Sending…';
    var payload = Object.assign({ _subject: 'Website enquiry: ' + data.service }, data);

    fetch(endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
      body: JSON.stringify(payload)
    }).then(function (res) {
      if (!res.ok) throw new Error('HTTP ' + res.status);
      form.reset();
      showStatus('ok', 'Thank you, your enquiry has been sent',
        'We have received your message and will reply to ' + data.email + '.');
    }).catch(function () {
      showStatus('err', 'Your enquiry could not be sent',
        'Please try again, or email ' + CONTACT_EMAIL + ' or call +971 54 130 4006 directly.');
    }).then(function () {
      submitBtn.disabled = false;
      submitBtn.innerHTML = label;
    });
  });
})();
